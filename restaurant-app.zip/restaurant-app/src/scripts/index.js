import "regenerator-runtime"; /* Digunakan untuk transpile async await */
import "../styles/main.css";

document.addEventListener("DOMContentLoaded", async () => {
  try {
    // Mengambil data dari file JSON
    const response = await fetch("/data/DATA.json");
    const data = await response.json();
    const restoranContainer = document.querySelector(".daftar-restoran");

    // Melakukan iterasi pada setiap data restoran dan membuat sebuah kartu untuk setiap restoran
    data.restaurants.forEach((restoran, index) => {
      const card = document.createElement("div");
      card.classList.add("card");
      card.setAttribute("tabindex", "0");
      card.id = `restoran-${index}`;

      const img = document.createElement("img");
      img.src = restoran.pictureId;
      img.alt = restoran.name;

      const nama = document.createElement("h2");
      nama.textContent = restoran.name;

      const deskripsi = document.createElement("p");
      deskripsi.textContent = restoran.description;

      const kota = document.createElement("p");
      kota.textContent = `Kota: ${restoran.city}`;

      const rating = document.createElement("p");
      rating.textContent = `Rating: ${restoran.rating}`;

      card.appendChild(img);
      card.appendChild(nama);
      card.appendChild(deskripsi);
      card.appendChild(kota);
      card.appendChild(rating);

      // Menambahkan event listener untuk menangani navigasi keyboard
      card.addEventListener("keydown", (event) => {
        if (event.key === "Enter") {
          window.location.href = `#restoran-${index}`;
        }
      });

      restoranContainer.appendChild(card);
    });
  } catch (error) {
    console.error("Error fetching data:", error);
  }
});

// Mengambil elemen menu hamburger
const hamburgerMenu = document.getElementById("hamburger-menu");

// Fungsi untuk toggle menu navbar
function toggleNavbar() {
  const navbarNav = document.querySelector(".navbar-nav");
  navbarNav.classList.toggle("show");

  const expanded = navbarNav.classList.contains("show");
  hamburgerMenu.setAttribute("aria-expanded", expanded);
  const ariaLabel = expanded ? "Close Menu" : "Menu";
  hamburgerMenu.setAttribute("aria-label", ariaLabel);
}

// Menambahkan event listener untuk mendeteksi klik pada menu hamburger dan toggle menu navbar
hamburgerMenu.addEventListener("click", toggleNavbar);

// Fungsi untuk menghandle event ketika mengklik di luar menu hamburger untuk menutupnya
document.addEventListener("click", function (event) {
  const navbarNav = document.querySelector(".navbar-nav");
  const isClickInsideHamburger = hamburgerMenu.contains(event.target);
  const isClickInsideNavbar = navbarNav.contains(event.target);

  if (!isClickInsideNavbar && !isClickInsideHamburger) {
    navbarNav.classList.remove("show");
    hamburgerMenu.setAttribute("aria-expanded", "false");
    hamburgerMenu.setAttribute("aria-label", "Menu");
  }
});
